import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity("test3table", { schema: "test3" })
export class Test3table {
  @PrimaryGeneratedColumn({ type: "int", name: "id" })
  id: number;

  @Column("varchar", { name: "test3", nullable: true, length: 255 })
  test3: string | null;
}
